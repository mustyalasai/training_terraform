for multiple vm creation
